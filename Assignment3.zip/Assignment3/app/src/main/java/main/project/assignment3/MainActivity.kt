package main.project.assignment3

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.drawable.VectorDrawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import main.project.assignment3.ui.theme.Assignment3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            loginPage()
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Preview
@Composable
fun loginPage(){
    var username by remember{ mutableStateOf("") }
    var password by remember{ mutableStateOf("") }
    var loggedIn by remember{ mutableStateOf(false) }
    Column(modifier= Modifier
        .fillMaxSize()
        .background(Color.Yellow.copy(alpha = 0.3f)),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            modifier = Modifier.padding(20.dp),
            painter = painterResource(id = R.drawable.ic_launcher_background),
            contentDescription = "login img"
        )
        Text(text = "LOGIN", fontFamily = FontFamily.Monospace, fontSize = 30.sp)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = username,
            onValueChange = { it -> username = it },
            label = { Text(text = "Username") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null
                )
            },
            colors = TextFieldDefaults.outlinedTextFieldColors(containerColor = Color.White)
        )
        OutlinedTextField(
            value = password,
            onValueChange = { it -> password = it },
            label = { Text(text = "Password") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null
                )
            },
            colors = TextFieldDefaults.outlinedTextFieldColors(containerColor = Color.White),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = null)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            loggedIn=!loggedIn
        }
        ) {
            Text(text = "Login")
        }
        Spacer(modifier = Modifier.height(50.dp))
        if(loggedIn){
            showLogins()
        }
    }
}
@Composable
fun showLogins(){
    val context = LocalContext.current
    Column {
        Row(modifier=Modifier.padding(20.dp)) {
            Image(painter = painterResource(id = R.drawable.amazon_icon), contentDescription = "Amazon_logo",
                modifier=Modifier.size(50.dp))
            Spacer(modifier = Modifier.width(30.dp))
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.com"))
                try{
                    context.startActivity(intent)
                }
                catch (e: ActivityNotFoundException){

                }
            }) {
                Text(text = "Visit")
            }
        }
        Row(modifier=Modifier.padding(20.dp)) {
            Image(painter = painterResource(id = R.drawable.flipkart_icon),
                contentDescription = "Flipkart_logo",
                modifier=Modifier.size(50.dp))
            Spacer(modifier = Modifier.width(30.dp))
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.flipkart.com"))
                try{
                    context.startActivity(intent)
                }
                catch (e: ActivityNotFoundException){

                }
            }) {
                Text(text = "Visit")
            }
        }
        Row(modifier=Modifier.padding(20.dp)) {
            Image(painter = painterResource(id = R.drawable.newegg_icon),
                contentDescription = "Newegg_logo",
                modifier=Modifier.size(50.dp))
            Spacer(modifier = Modifier.width(30.dp))
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.newegg.com"))
                try{
                    context.startActivity(intent)
                }
                catch (e: ActivityNotFoundException){

                }
            }) {
                Text(text = "Visit")
            }
        }
    }
}
